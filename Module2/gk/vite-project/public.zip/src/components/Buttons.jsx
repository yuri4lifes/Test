
const Buttons = (props) => {
  return (
    <button className='Buttons'>{props.txt}</button>
  )
}
  
export default Buttons