const Screen = (props) => {
  return (
    <div className="screen">{props.txt}</div>
  )
}

export default Screen