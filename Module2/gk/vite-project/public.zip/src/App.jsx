import { useState } from 'react';
import './App.css'


function App() {
  const [tempArray,setArray]=useState([])
  const [temp,setTemp]=useState("")
 
  const myList = tempArray.map((item,index)=><div className='toDo' key={index}>{item.name}  <input type="checkbox" onClick={()=>handleBox(index)} /></div>)
  const trueList=tempArray.filter((item)=>item.status==true).map((item,index)=><div className='toDo' key={index}>{item.name}  <input type="checkbox" onClick={()=>handleBox(index)} /></div>)
  const falseList=tempArray.filter((item)=>item.status==true).map((item,index)=><div className='toDo' key={index}>{item.name}  <input type="checkbox" onClick={()=>handleBox(index)} /></div>)
  
  const [screen,setScreen]=useState(myList)
  const myArray = tempArray;
  
  
  const handleChange=(e)=>{
    setTemp(e.target.value)
  }

  const handleBtn=()=>{
    const item={name:temp,status:false}
    myArray.push(item)
    setArray(myArray)
    setScreen(myList)
    
  }
  
  const handleBox=(index)=>{
    myArray[index].status=!myArray[index].status
    setArray(myArray)
    console.log(tempArray[index])
  } 

  
  return (
    <>
      <input onChange={handleChange}/>
      <button onClick={handleBtn}>submit</button>
      <button onClick={()=>setScreen(falseList)}>false</button>
      <button onClick={()=>setScreen(trueList)}>true</button>
      {screen}
    </>
  )
}

export default App
